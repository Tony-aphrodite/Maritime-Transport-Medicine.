<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Admin Login</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <h1>Test Admin Login</h1>
    
    <?php if(session('error')): ?>
        <div style="color: red; padding: 10px; border: 1px solid red; margin: 10px 0;">
            Error: <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div style="color: green; padding: 10px; border: 1px solid green; margin: 10px 0;">
            Success: <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
        <?php echo csrf_field(); ?>
        
        <div style="margin: 10px 0;">
            <label>Email:</label><br>
            <input type="email" name="email" value="AdminJuan@gmail.com" style="width: 300px; padding: 5px;" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="margin: 10px 0;">
            <label>Password:</label><br>
            <input type="password" name="password" value="johnson@suceess!" style="width: 300px; padding: 5px;" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" style="padding: 10px 20px; background: blue; color: white; border: none;">
            Login
        </button>
    </form>

    <div style="margin-top: 20px;">
        <p><strong>Expected Credentials:</strong></p>
        <p>Email: AdminJuan@gmail.com</p>
        <p>Password: johnson@suceess!</p>
    </div>

    <div style="margin-top: 20px;">
        <a href="/admin/login">Go to Real Admin Login</a> | 
        <a href="/admin/dashboard">Go to Admin Dashboard</a>
    </div>
</body>
</html><?php /**PATH /home/houseph/Project/Maritime-Transport-Medicine./resources/views/admin/test-login.blade.php ENDPATH**/ ?>